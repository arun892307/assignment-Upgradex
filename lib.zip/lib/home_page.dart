import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Home_Page extends StatefulWidget {
  const Home_Page({Key? key}) : super(key: key);
 static const List<String> Items_1=["Earphones","Women","Girls","Tops","Men","Bags","Home","Shoes"];


  @override
  State<Home_Page> createState() => _Home_PageState();
}

class _Home_PageState extends State<Home_Page> {
  static const List<String> price=["1099","499","799","599","1199","499","599","699"];
  var current_page=0;
  @override
  Widget build(BuildContext context) {
    Size size=MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      drawer: const Drawer(

        backgroundColor: Colors.blue,
      ),
      appBar: AppBar(
          title:
           Row(mainAxisAlignment: MainAxisAlignment.start, children: [
          Image.asset('assets/images/myntra-Logo-PNG_zqavvs.png',
          fit: BoxFit.contain, height: 24),
          ]),
        backgroundColor: Colors.white,
        actions:<Widget> [
               IconButton(
                 padding: EdgeInsets.only(right:size.width/20 ),
                   onPressed: (){},
                   icon: const Icon(Icons.add_box_outlined,weight:1,size: 32,color:Colors.black)),
          IconButton(
              padding: EdgeInsets.only(right:size.width/17 ),
              onPressed: (){},
              icon: const Icon(Icons.search,weight: 1,size: 32,color: Colors.black,)),
          IconButton(
              padding: EdgeInsets.only(right:size.width/15 ),
              onPressed: (){},
              icon: const Icon(Icons.favorite_border,weight: 1,size: 32,color: Colors.black,)),
          IconButton(
              padding: EdgeInsets.only(right:size.width/18 ),
              onPressed: (){},
              icon: const Icon(Icons.shopping_bag_outlined,weight: 1,size: 32,color:Colors.black,))

        ],
          iconTheme: const IconThemeData(color: Colors.black,size: 32)
      ),

      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        physics: const ClampingScrollPhysics(),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: size.height*0.15,
              child: ListView.builder(
                  padding:  const EdgeInsets.only(top: 16,left: 10),
                  scrollDirection: Axis.horizontal,
                  itemCount: 8,
                  itemBuilder: (context, index) =>
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            margin: const EdgeInsets.only(right: 8),
                            height: size.height*0.083,
                            width: size.width*0.20,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                                image: DecorationImage(image: AssetImage("assets/images/img_${index}.png"),fit: BoxFit.fill)
                            ),
                          ),
                          AutoSizeText(
                           Home_Page.Items_1[index],
                              style: GoogleFonts.lexend(
                                  color: Colors.black,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w300)
                          ),
                        ],
                      )
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 0),
              child: Container(
                height: size.height*0.32,
                width: size.width*1,
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(topLeft:Radius.circular(12.0),topRight: Radius.circular(12.0)),
                  image: DecorationImage(
                    image: AssetImage("assets/images/sale_1.jpg"),
                    fit: BoxFit.fill

                  )
                ),
              ),
            ),
            Center(
            child: Padding(
              padding:  EdgeInsets.only(top: size.height/80,bottom: size.height/80),
              child: Container(
                margin: const EdgeInsets.only(right: 8),
                height: size.height*0.055,
                width: size.width*0.94,
                decoration: const BoxDecoration(
                    color: Colors.black,
                  borderRadius: BorderRadius.all(Radius.circular(15.0))
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AutoSizeText(
                      "Sign Up For Exciting Deals!",
                    style: GoogleFonts.lexend(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w600)
                    ),
                    IconButton(onPressed: (){},
                        icon: const Icon(Icons.arrow_forward_ios_rounded,color: Colors.white,size: 22,weight: 1,)
                    )
                  ],
                ),
              ),
            ),
          ),
            Padding(
              padding:  EdgeInsets.only(top: 5),
              child: SizedBox(
                 width: size.width*1,
                height: size.height*0.34,
                child: PageView(
                  scrollDirection: Axis.horizontal,
                  reverse: false,
                  physics: const BouncingScrollPhysics(),
                  pageSnapping: true,
                  onPageChanged: (index){
                    setState(() {
                      current_page=index;
                    });
                  },
                  children: [
                    Column(
                      //crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 0,left: 5,right: 5),
                          child: Container(
                            width: MediaQuery.of(context).size.width*1,
                            height: MediaQuery.of(context).size.height*0.27,
                            decoration: const BoxDecoration(
                                color: Colors.white,
                                image: DecorationImage(
                                  image: AssetImage("assets/images/list_0.jpg"),
                                  fit:BoxFit.fill,
                                  //alignment: Alignment.topCenter)
                                )
                            ),
                          ),
                        ),
                        const SizedBox(height: 13,),
                        row(),
                      ],
                    ),
                    Column(
                      //crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 0,left: 5,right: 5),
                          child: Container(
                            width: MediaQuery.of(context).size.width*1,
                            height: MediaQuery.of(context).size.height*0.27,
                            decoration: const BoxDecoration(
                                color: Colors.white,
                                image: DecorationImage(
                                  image: AssetImage("assets/images/list_1.png"),
                                  fit:BoxFit.fill,
                                  //alignment: Alignment.topCenter)
                                )
                            ),
                          ),
                        ),
                        const SizedBox(height: 13,),
                        row(),
                      ],
                    ),
                    Column(
                      //crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 0,left: 5,right: 5),
                          child: Container(
                            width: MediaQuery.of(context).size.width*1,
                            height: MediaQuery.of(context).size.height*0.27,
                            decoration: const BoxDecoration(
                                color: Colors.white,
                                image: DecorationImage(
                                  image: AssetImage("assets/images/list_2.png"),
                                  fit:BoxFit.fill,
                                  //alignment: Alignment.topCenter)
                                )
                            ),
                          ),
                        ),
                        const SizedBox(height: 13,),
                        row(),
                      ],
                    ),
                    Column(
                      //crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 0,left: 5,right: 5),
                          child: Container(
                            width: MediaQuery.of(context).size.width*1,
                            height: MediaQuery.of(context).size.height*0.27,
                            decoration: const BoxDecoration(
                                color: Colors.white,
                                image: DecorationImage(
                                  image: AssetImage("assets/images/list_3.png"),
                                  fit:BoxFit.fill,
                                  //alignment: Alignment.topCenter)
                                )
                            ),
                          ),
                        ),
                        const SizedBox(height: 13,),
                        row(),
                      ],
                    ),
                    Column(
                      //crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 0,left: 5,right: 5),
                          child: Container(
                            width: MediaQuery.of(context).size.width*1,
                            height: MediaQuery.of(context).size.height*0.27,
                            decoration: const BoxDecoration(
                                color: Colors.white,
                                image: DecorationImage(
                                  image: AssetImage("assets/images/list_4.png"),
                                  fit:BoxFit.fill,
                                  //alignment: Alignment.topCenter)
                                )
                            ),
                          ),
                        ),
                        const SizedBox(height: 13,),
                        row(),
                      ],
                    ),
                  ],

                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  height: size.height*0.063,
                  width: size.width*0.30,
                  decoration: const BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.all(Radius.circular(10.0)),
                      image: DecorationImage(
                          image: AssetImage("assets/images/card.jpg"),
                          fit: BoxFit.fill

                      )
                  ),
                ),
                Container(
                  height: size.height*0.063,
                  width: size.width*0.30,
                  decoration: const BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.all(Radius.circular(10.0)),
                      image: DecorationImage(
                          image: AssetImage("assets/images/card.jpg"),
                          fit: BoxFit.fill

                      )
                  ),
                ),
                Container(
                  height: size.height*0.063,
                  width: size.width*0.30,
                  decoration: const BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.all(Radius.circular(10.0)),
                      image: DecorationImage(
                          image: AssetImage("assets/images/card.jpg"),
                          fit: BoxFit.fill
                      )
                  ),
                ),
              ],
            ),
            SizedBox(
              height: size.height*0.012,
            ),
            Column(
              children: [
                Padding(
                  padding:  EdgeInsets.all(size.height*0.012),
                  child: AutoSizeText(
                    "ALL-TIME FAVOURITES",
                    style: GoogleFonts.lexend(
                        color: Colors.black87,
                        fontSize: 25,
                        fontWeight: FontWeight.w700),
                  ),
                ),
                SizedBox(
                  height: size.height*0.01,
                ),
                SizedBox(
                  height: size.height*0.81,
                  width: size.width*0.96,
                  child: GridView.builder(
                   gridDelegate:  SliverGridDelegateWithFixedCrossAxisCount(
                   crossAxisCount: 2,
                   mainAxisSpacing: size.height*0.022,
                   mainAxisExtent: size.height*0.18,
                     crossAxisSpacing: size.width*0.032,
                       ),
                    shrinkWrap: true,
                    itemCount: 8,
                   physics: const ClampingScrollPhysics(),
                   scrollDirection: Axis.vertical,
                   itemBuilder: (context, index) {
                        return Material(
                          elevation: 3,
                          borderRadius: const BorderRadius.all(Radius.circular(0)),
                          child:Column(
                            children: [
                              Container(
                                height: size.height * 0.13,
                                width: size.width * 0.45,
                                decoration: BoxDecoration(
                                    border: Border.all(color: Colors.grey,width: 1),
                                    borderRadius: const BorderRadius.all(Radius.circular(12.0)),
                                    image: DecorationImage(
                                        image: AssetImage("assets/images/img_$index.png"),
                                        fit: BoxFit.fill)),
                              ),
                              SizedBox(
                                height: size.height * 0.05,
                                width: size.width*0.4,
                                child: Center(
                                  child: AutoSizeText(
                                    "Under \u{20B9} ${price[index]}",
                                    style: GoogleFonts.lexend(
                                        color: Colors.black87,
                                        fontSize: 22,
                                        fontWeight: FontWeight.w800),
                                  ),
                                ),
                              )
                            ],
                          ) ,
                        );
                   }
                  ),
                ),
                Container(
                  margin: const EdgeInsets.only(right: 8),
                  height: size.height*0.035,
                  width: size.width*0.94,
                  decoration: const BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.all(Radius.circular(8.0))
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AutoSizeText(
                          "View All",
                          style: GoogleFonts.lexend(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w600)
                      ),
                      IconButton(onPressed: (){},
                          icon: const Icon(Icons.arrow_forward_ios_rounded,color: Colors.white,size: 22,weight: 1,)
                      )
                    ],
                  ),
                ),
                SizedBox(
                  height: size.height*0.060,
                  width: size.width*9,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 20,left: 10),
                    child: AutoSizeText(
                        "HIGHLIGHTS OF THE DAY",
                        style: GoogleFonts.lexend(
                            color: Colors.black87,
                            fontSize: 18,
                            fontWeight: FontWeight.w600)
                    ),
                  ),
                ),
                SizedBox(
                  height: size.height*0.26,
                  child: ListView.builder(
                      padding:  const EdgeInsets.only(top: 16,left: 10),
                      scrollDirection: Axis.horizontal,
                      itemCount: 5,
                      itemBuilder: (context, index) =>
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                height: size.height * 0.9,
                                width: size.width * 0.4,
                                decoration:  BoxDecoration(
                                  border: Border.all(color: Colors.grey,width: 1),
                                    borderRadius: const BorderRadius.all(Radius.circular(5)),
                                    image: DecorationImage(
                                        image: AssetImage("assets/images/fashion_$index.png"),
                                        fit: BoxFit.fill)),
                              ),
                              SizedBox(
                                width: size.width*0.022,
                              )
                            ],
                          ),

                  ),
                ),
                SizedBox(
                  height: size.height*0.2,
                ),
                SizedBox(
                  height: size.height*0.26,
                  child: ListView.builder(
                    padding:  const EdgeInsets.only(top: 16,left: 10),
                    scrollDirection: Axis.horizontal,
                    itemCount: 5,
                    itemBuilder: (context, index) =>
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              height: size.height * 0.9,
                              width: size.width * 0.4,
                              decoration:  BoxDecoration(
                                  border: Border.all(color: Colors.grey,width: 1),
                                  borderRadius: const BorderRadius.all(Radius.circular(5)),
                                  image: DecorationImage(
                                      image: AssetImage("assets/images/fashion_$index.png"),
                                      fit: BoxFit.fill)),
                            ),
                            SizedBox(
                              width: size.width*0.022,
                            )
                          ],
                        ),

                  ),
                )
              ],
            ),
            Stack(
              children: [

              ],
            )





          ],
        ),
      ),
    );
  }
  Widget row()
  {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,

      children: [
        current_page==0?const Icon(Icons.circle,size: 13,color: Colors.blue,):const Icon(Icons.circle_outlined,size: 13,color: Colors.grey,),
        current_page==1?const Icon(Icons.circle,size: 13,color: Colors.blue,):const Icon(Icons.circle_outlined,size: 13,color: Colors.grey,),
        current_page==2?const Icon(Icons.circle,size: 13,color: Colors.blue,):const Icon(Icons.circle_outlined,size: 13,color: Colors.grey,),
        current_page==3?const Icon(Icons.circle,size: 13,color: Colors.blue,):const Icon(Icons.circle_outlined,size: 13,color: Colors.grey,),
        current_page==4?const Icon(Icons.circle,size: 13,color: Colors.blue,):const Icon(Icons.circle_outlined,size: 13,color: Colors.grey,),

      ],
    );
  }
}
